var formidable = require("formidable");
var User = require("../models/User.js");
var crypto = require("crypto");

exports.doLogin = (req,res) =>{
    //拿到email和pwd
	//下面两句话来自formidable，来自：https://www.npmjs.com/package/formidable
	var form = new formidable.IncomingForm();
	form.parse(req, function(err, fields, files) {
		var email = fields.email;
		var pwd = fields.pwd;

		User.find({"email":email},(err,docs)=>{
			if(docs.length == 0){
				res.send({"result" : -1});
				return;
			}
			//加密密码
			pwd = crypto.createHash('sha256').update("我爱" + pwd + "考拉").digest("hex");
 
			if(docs[0].pwd == pwd){
				//下发session，session一切，有效减少数据库的查询
				req.session.login = true;
				req.session.email = email;
				res.send({"result" : 1});
			}else{
				res.send({"result" : -2});
			}
		});
	});
}