define(function(require){
	var app = require("../app");
	//子组件的注册

	app.controller("BaobiaoCtrl",[function(){
		 
	}]);
});